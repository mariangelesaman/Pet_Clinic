<template>
    <div id="figura">
     <h3>Pesquisar</h3>
     <h5>Escreva o nome da sua mascote!</h5>   
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>