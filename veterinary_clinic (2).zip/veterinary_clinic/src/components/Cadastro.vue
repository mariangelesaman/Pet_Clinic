<template>
     <div id="Cadastro">
     <h3>Novo Cadastro</h3>
     <h5>Realize o cadastro da sua mascote!</h5>   
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>