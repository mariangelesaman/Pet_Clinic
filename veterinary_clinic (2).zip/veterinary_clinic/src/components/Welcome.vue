<template>
    <div class="image">
        <img alt="Vue Pet" src="">
        <h2>Lhe damos as boasvindas ao Vue Pet Clinic</h2>
        <h4>Uma forma muito rapida e facil de cadastrar seus pets!</h4>
    </div> 
</template>

<script>
export default {
    name: 'Welcome',
  props: {
    msg: String
  }
}
</script>

<style scoped>

</style>