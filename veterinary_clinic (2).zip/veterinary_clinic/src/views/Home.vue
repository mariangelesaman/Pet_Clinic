<template>
  <div>
    <div class="card">
      <div class="card-body"><boasvindas /></div>
    </div>
    <div class="row">
      <div class="col-3"></div>

      <div class="col-3" id="Pesquisa">
        <button
          @click="IrParaPesquisa"
          type="button"
          class="btn btn-outline-primary"
        >
          <card-pesquisa />
        </button>
      </div>

      <div class="col-3" id="Cadastro">
        <button
          @click="IrParaCadastro"
          type="button"
          class="btn btn-outline-success"
        >
          <card-cadastro />
        </button>
      </div>

      <div class="col-3"></div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import Welcome from "@/components/Welcome.vue";
import Cadastro from "@/components/Cadastro.vue";
import Pesquisa from "@/components/Pesquisa.vue";

export default {
  name: "Home",
  components: {
    Welcome,
    Cadastro,
    Pesquisa,
  },
  methods: {
    IrParaPesquisa() {
      this.$router.push({ path: "/Pesquisa" });
    },
    IrParaCadastro() {
      this.$router.push({ path: "/Cadastro" });
    },
  },
};
</script>
<style>
.Pesquisa {
  align-content: left;
  width: 250px;
}
.Cadastro {
  align-content: right;
  width: 250px;
}
</style>